Imports System

Public Module MyProgram
    Sub Main
        Dim nama As String, jKL As String
        Dim bB As Double, tB As Double, usia As Double, bMRp As Double, bMRw As Double, tDEEKalHp As Double, tDEEKalHw As Double

        Console.WriteLine("Silahkan masukkan nama anda")
        nama = Console.ReadLine()
        Console.WriteLine("Masukkan jenis kelamin anda (Pria/Wanita)")
        jKL = Console.ReadLine()
        Console.WriteLine("Masukkan berat badan anda")
        bB = inputValue()
        Console.WriteLine("Silahkan masukkan tinggi badan anda")
        tB = inputValue()
        Console.WriteLine("Silahkan masukkan usia anda")
        usia = inputValue()
        If jKL = "Wanita" Then
            bMRw = 10 * bB + 6.25 * tB - 5 * usia - 161
            Console.WriteLine("Jumlah minimum kalori yang dibutuhkan tubuh anda: " & bMRw & "kkal/hari")
            tDEEKalHw = bMRw * 1.375
            Console.WriteLine("Jumlah total kalori yang dibakar oleh tubuh anda setiap harinya: " & tDEEKalHw & "kkal/hari")
        Else
            bMRp = 10 * bB + 6.25 * tB - 5 * usia + 5
            Console.WriteLine("Jumlah minimum kalori yang dibutuhkan tubuh anda: " & bMRp & "kkal/hari")
            tDEEKalHp = bMRp * 1.375
            Console.WriteLine("Jumlah total kalori yang dibakar oleh tubuh anda setiap harinya: " & tDEEKalHp & "kkal/hari")
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
