Imports System

Public Module MyProgram
    Sub Main
        Dim kembalian As Double, sisa As Double, koin As Double
        Dim u100000 As Integer, u50000 As Integer, u20000 As Integer, u10000 As Integer, u5000 As Integer, u2000 As Integer, u1000 As Integer

        Console.WriteLine("Silahkan masukkan jumlah uang kembalian anda")
        kembalian = inputValue()
        u100000 = kembalian / 100000
        sisa = kembalian Mod 100000
        u50000 = kembalian / 50000
        sisa = kembalian Mod 50000
        u20000 = kembalian / 20000
        sisa = kembalian Mod 20000
        u10000 = kembalian / 10000
        sisa = kembalian Mod 10000
        u5000 = kembalian / 5000
        sisa = kembalian Mod 5000
        u2000 = kembalian / 2000
        sisa = kembalian Mod 2000
        u1000 = kembalian / 1000
        sisa = kembalian Mod 1000
        koin = sisa
        Console.WriteLine("Rp100.000: " & u100000 & "lembar")
        Console.WriteLine("Rp50.000: " & u50000 & "lembar")
        Console.WriteLine("Rp20.000: " & u20000 & "lembar")
        Console.WriteLine("Rp10.000: " & u10000 & "lembar")
        Console.WriteLine("Rp5.000: " & u5000 & "lembar")
        Console.WriteLine("Rp2.000: " & u2000 & "lembar")
        Console.WriteLine("Rp1.000: " & u1000 & "lembar")
        Console.WriteLine("Sisa koin anda: " & koin & "perak")
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
