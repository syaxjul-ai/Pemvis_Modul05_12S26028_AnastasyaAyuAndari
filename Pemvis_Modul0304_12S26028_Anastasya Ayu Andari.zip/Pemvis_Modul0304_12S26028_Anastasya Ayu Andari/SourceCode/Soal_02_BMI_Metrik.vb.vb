Imports System

Public Module MyProgram
    Sub Main
        Dim bB As Double, tB As Double, usia As Double, bMI As Double

        Console.WriteLine("Masukkan berat badan anda")
        bB = inputValue()
        Console.WriteLine("Masukkan tinggi badan anda")
        tB = inputValue()
        Console.WriteLine("Masukkan usia anda")
        usia = inputValue()
        bMI = bB / tB ^ 2
        If bMI < 18.5 Then
            Console.WriteLine("Berdasarkan perhitungan massa indeks tubuh yang sudah dilakukan, berat badan anda dinyatakan underweight")
        Else
            If bMI >= 18.5 And bMI < 25.0 And usia >= 18 And usia <= 60 Then
                Console.WriteLine("Berdasarkan perhitungan massa indeks tubuh yang sudah dilakukan, berat badan anda dinyatakan normal / ideal")
            Else
                If bMI >= 25.0 And bMI < 30.0 Then
                    Console.WriteLine("Berdasarkan perhitungan massa indeks tubuh yang sudah dilakukan, berat badan anda dinyatakan overweight")
                Else
                    If bMI >= 30.0 Then
                        Console.WriteLine("Berdasarkan perhitungan massa indeks tubuh yang sudah dilakukan, berat badan anda dinyatakan obesitas")
                    End If
                End If
            End If
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
